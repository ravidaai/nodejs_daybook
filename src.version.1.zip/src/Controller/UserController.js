const UserService = require("../Service/UserService");
const UserValidation = require("../Validation/UserValidation");
const LoginValidation = require("../Validation/LoginValidation");
module.exports = {
  create: async (req, res, next) => {
    try {
      const { error } = UserValidation.createValidation(req);
      if (error) {
        res
          .status(400)
          .json({
            message: "Error",
            data: { error: error.details[0].message },
            statusCode: 400,
          });
      } else {
        const result = await UserService.Create(req, res);
        res.status(res.statusCode).json(result);
      }
    } catch (error) {
      throw error;
    }
  },
  login: async (req, res, next) => {
    try {
      const { error } = LoginValidation.loginValidation(req);
      if (error) {
        res
          .status(400)
          .json({
            message: "Error",
            data: { error: error.details[0].message },
            statusCode: 400,
          });
      } else {
        const result = await UserService.Login(req, res);
        res.status(res.statusCode).json(result);
      }
    } catch (error) {
      throw error;
    }
  },
  changePassword: async (req, res, next) => {
    try {
      const { error } = UserValidation.changePasswordValidation(req);
      if (error) {
        res.status(400).json({
            message: "Error",
            data: { error: error.details[0].message },
            statusCode: 400,
          });
      }else{
        const result = await UserService.ChangePassword(req, res);
        res.status(res.statusCode).json(result);
      }
    } catch (error) {
      throw error;
    }
  },
};
