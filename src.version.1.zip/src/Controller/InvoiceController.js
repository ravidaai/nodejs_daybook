const InvoiceService = require("../Service/InvoiceService");
const InvoiceValidation = require("../Validation/InvoiceValidation");
module.exports = {
  delete: async (req, res) => {
    try {
      const result = await InvoiceService.Delete(req, res);
      res.status(result.statusCode).json(result);
    } catch (error) {
      throw error;
    }
  },
  update: async (req, res) => {
    try {
      const { error } = InvoiceValidation.updateValidation(req);
      if (error) {
        res.status(400).json({
          message: "Error",
          data: { error: error.details[0].message },
          statusCode: 400,
        });
      } else {
        const result = await InvoiceService.Update(req, res);
        res.status(result.statusCode).json(result);
      }
    } catch (error) {
      throw error;
    }
  },

  create: async (req, res) => {
    try {
      const { error } = InvoiceValidation.createValidation(req);
      if (error) {
        res.status(400).json({
          message: "Error",
          data: { error: error.details[0].message },
          statusCode: 400,
        });
      } else {
        const result = await InvoiceService.Create(req, res);
        res.status(result.statusCode).json(result);
      }
    } catch (error) {
      throw error;
    }
  },
  show: async (req, res) => {
    try {
      
      const result = await InvoiceService.Show(req, res);
      res.status(result.statusCode).json(result);
    } catch (error) {
      throw error;
    }
  },
  index: async (req, res) => {
    try {
      const { error } = InvoiceValidation.indexValidation(req);
      if (error) {
        res.status(400).json({
          message: "Error",
          data: { error: error.details[0].message },
          statusCode: 400,
        });
      } else {
        const result = await InvoiceService.Index(req, res);
        res.status(result.statusCode).json(result);
      }
    } catch (error) {
      throw error;
    }
  },
};
