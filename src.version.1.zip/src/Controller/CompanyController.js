const CompanyService = require("../Service/CompanyService");
const CompanyValidation = require("../Validation/CompanyValidation");
module.exports = {
  delete: async (req, res) => {
    try {
      const result = await CompanyService.Delete(req, res);
      res.status(result.statusCode).json(result);
    } catch (error) {
      throw error;
    }
  },
  update: async (req, res) => {
    try {
      const { error } = CompanyValidation.createValidation(req);
      if (error) {
        res.status(400).json({
          message: "Error",
          data: { error: error.details[0].message },
          statusCode: 400,
        });
      } else {
        const result = await CompanyService.Update(req, res);
        res.status(result.statusCode).json(result);
      }
      
    } catch (error) {
      throw error;
    }
  },

  create: async (req, res) => {
    try {
      const { error } = CompanyValidation.createValidation(req);
      if (error) {
        res.status(400).json({
          message: "Error",
          data: { error: error.details[0].message },
          statusCode: 400,
        });
      } else {
        const result = await CompanyService.Create(req, res);
        res.status(result.statusCode).json(result);
      }
    } catch (error) {
      throw error;
    }
  },
  show: async (req, res) => {
    try {
      const result = await CompanyService.Show(req, res);
      res.status(result.statusCode).json(result);
    } catch (error) {
      throw error;
    }
  },
  index: async (req, res) => {
    try {
      const result = await CompanyService.Index(req, res);
      res.status(result.statusCode).json(result);
      //res.status(200).json(req.auth);
    } catch (error) {
      throw error;
    }
  },
};
