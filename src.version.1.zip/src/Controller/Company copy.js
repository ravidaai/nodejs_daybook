const mongoose = require("mongoose");
const CompanyModel = require("../Model/CompanyModel");
module.exports = {
  createCompany: async (company_name) => {
    
    const Company = new CompanyModel({
      _id: new mongoose.Types.ObjectId(),
      company_name: company_name
    });

    
    try {
      /***JUST REMINDER */
      //Do not write all login in controller in this way.
      // const isBestSeller = await axios.get('some_third_part_url');
      //       // if best seller do we have that book in our store
      //       if(isBestSeller) {
      //           // Run Additional Database query to figure our
      //           //...
      //           //if not send library admin and email
      //           //...
      //           // other logic and such
      //       }

      //Write logic in seperate service folder
      // await AuthorService.checkauthorSalesStatus();
      // await BookService.checkAvailableBooksByAuthor(name);
      /********** */
      result = await Company.save() 
      return result

      // const NewCompanyEntry = await Company.save();
      // return NewCompanyEntry;
    } catch (error) {
      throw error;
    }
  },

  getCompany: async (id) => {
    // ..
  },

  getAllCompanies: async () => {
    // ...
  },
};
