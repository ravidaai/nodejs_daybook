const InvoiceCategoryService = require("../Service/InvoiceCategoryService");
const InvoiceCategoryValidation = require("../Validation/InvoiceCategoryValidation");
module.exports = {
  delete: async (req, res) => {
    try {
      const result = await InvoiceCategoryService.Delete(req, res);
      res.status(result.statusCode).json(result);
    } catch (error) {
      throw error;
    }
  },
  update: async (req, res) => {
    try {
      const { error } = InvoiceCategoryValidation.createValidation(req);
      if (error) {
        res.status(400).json({
          message: "Error",
          data: { error: error.details[0].message },
          statusCode: 400,
        });
      } else {
        const result = await InvoiceCategoryService.Update(req, res);
        res.status(result.statusCode).json(result);
      }
      
    } catch (error) {
      throw error;
    }
  },

  create: async (req, res) => {
    try {
      const { error } = InvoiceCategoryValidation.createValidation(req);
      if (error) {
        res.status(400).json({
          message: "Error",
          data: { error: error.details[0].message },
          statusCode: 400,
        });
      } else {
        const result = await InvoiceCategoryService.Create(req, res);
        res.status(result.statusCode).json(result);
      }
    } catch (error) {
      throw error;
    }
  },
  show: async (req, res) => {
    try {
      const result = await InvoiceCategoryService.Show(req, res);
      res.status(result.statusCode).json(result);
    } catch (error) {
      throw error;
    }
  },
  index: async (req, res) => {
    try {
      const result = await InvoiceCategoryService.Index(req, res);
      res.status(result.statusCode).json(result);
    } catch (error) {
      throw error;
    }
  },
};
