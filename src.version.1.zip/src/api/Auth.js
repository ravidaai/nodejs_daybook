const express = require('express');
const router = express.Router();
const UserController = require('../Controller/UserController');
const verifyToken = require('../Middleware/verifyToken');

/**
 * POST request to /user
 */
 router.post("/",  async (req, res, next) => {
    await UserController.create(req, res);
});

/**
 * POST request to /login
 */
 router.post("/login",  async (req, res, next) => {
    await UserController.login(req, res);
});

/**
 * POST request to /change_password
 */
 router.post("/change_password", verifyToken, async (req, res, next) => {
    await UserController.changePassword(req, res);
});

module.exports = router;