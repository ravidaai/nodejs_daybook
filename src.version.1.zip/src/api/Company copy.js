const express = require('express');
const router = express.Router();
const companyController = require('../Controller/Company');

/**
 * GET request to /company
 */
router.get('/', async (req, res, next) => {
    const company = await companyController.getAllCompanies()
    res.status(200).json({
        message: company.message,
        data: company.data
    });
});

/**
 * GET request to /company/:id
 */
router.get('/:company_id', async(req, res, next) => {
    const company = await companyController.getCompany(req.params.company_id);
    res.status(201).json({
        message: company.message,
        data: company.data
    })
});

/**
 * POST request to /company
 */
router.post("/", async (req, res, next) => {
    const company = await companyController.createCompany(req.body.company_name)
    res.status(201).json({
        message: company.message,
        data: company.data
    })
});

/**
 * Delete request to /company/:id
 */
 router.delete('/:company_id', async(req, res, next) => {
    const company = await companyController.deleteCompany(req.params.company_id);
    res.status(201).json({
        message: company.message,
        data: company.data
    })
});


/**
 * Update request to /company/:id
 */
 router.patch('/:company_id', async(req, res, next) => {
    const company = await companyController.updateCompany(req.params.company_id, req.body.company_name);
    res.status(201).json({
        message: company.message,
        data: company.data
    })
});
  

module.exports = router;