const express = require('express');
const router = express.Router();
const companyController = require('../Controller/CompanyController');
const verifyToken = require('../Middleware/verifyToken');
/**
 * GET request to /company
 */
router.get('/', verifyToken,  async (req, res, next) => {
    await companyController.index(req, res)
});

/**
 * GET request to /company/:id
 */
router.get('/:company_id', verifyToken, async(req, res, next) => {
    await companyController.show(req, res);
});

/**
 * POST request to /company
 */
router.post("/", verifyToken, async (req, res, next) => {
    await companyController.create(req, res)
});

/**
 * Delete request to /company/:id
 */
 router.delete('/:company_id', verifyToken, async(req, res, next) => {
   await companyController.delete(req, res);

});

/**
 * Update request to /company/:id
 */
 router.patch('/:company_id', verifyToken, async(req, res, next) => {
    await companyController.update(req, res);
});
  

module.exports = router;