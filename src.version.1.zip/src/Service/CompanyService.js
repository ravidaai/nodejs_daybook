const mongoose = require("mongoose");
const ObjectID = require('mongodb').ObjectID;
const _ = require("lodash");
const CompanyModel = require("../Model/CompanyModel");



module.exports = {
  
  Create: async (req, res) => {
    const Company = new CompanyModel({
      _id: new mongoose.Types.ObjectId(),
      company_name: req.body.company_name,
      user:req.auth._id 
    });

    try {
      
      if (await CompanyModel.findOne({ company_name: req.body.company_name})) {
        return {  message: "Company Already Exist.", data : {}, statusCode: 409};
      } else {
        companyResult = await Company.save();
        return {message: "Company successfully created.",data: companyResult, statusCode: 200};
      }

    } catch (error) {
      throw error;
    }
  },

  Update: async (req, res) => {
    try {
        if (await CompanyModel.exists({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) })) {
          const Company = await CompanyModel.updateOne({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) }, {$set:{company_name: req.body.company_name}});
          return {
            message: "Company Updated.",
            data: Company,
            statusCode: 200
          };
        } else {
          return {
            message: "Company Not Exist.",
            data: {},
            statusCode: 404
          };
        }
      } catch (error) {
        throw error;
      }
  },

  Show: async (req, res) => {
    try {
      if (await CompanyModel.exists({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) })) {
        //const Company = await CompanyModel.findById(req.params.company_id);
        const Company =  await CompanyModel.findOne({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) });
        return {
          message: "Company Exist.",
          data: Company,
          statusCode: 201,
        };
      } else {
        return {
          message: "Company Not Exist.",
          data: {},
          statusCode: 404,
        };
      }
    } catch (error) {
      throw error;
    }
  },
  Delete: async (req, res) => {
    try {
        if (await CompanyModel.findOne({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) })) {
          const Company = await CompanyModel.remove({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) });
          return {
            message: "Company Deleted.",
            data: Company,
            statusCode: 200
          };
        } else {
          return {
            message: "Company Not Exist.",
            data: {},
            statusCode: 404
          };
        }
      } catch (error) {
        throw error;
      }
  },

  Index: async (req, res) => {
    try { 
      //const isExist = await CompanyModel.exists({ user: req.auth._id });
      const Company = await CompanyModel.find({user:  mongoose.Types.ObjectId(req.auth._id)});
      result = {
        message: "All company",
        data: Company,
        statusCode:200
      };

      return result;
    } catch (error) {
      throw error;
    }
  },
};
