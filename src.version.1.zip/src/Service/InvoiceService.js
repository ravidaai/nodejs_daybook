const mongoose = require("mongoose");
const ObjectID = require("mongodb").ObjectID;
const _ = require("lodash");
const InvoiceModel = require("../Model/InvoiceModel");
const CompanyModel = require("../Model/CompanyModel");
const InvoiceCategoryModel = require("../Model/InvoiceCategoryModel");

module.exports = {
  Create: async (req, res) => {
    try {
      if (
        await CompanyModel.exists({
          _id: mongoose.Types.ObjectId(req.body.company_id),
          user: mongoose.Types.ObjectId(req.auth._id),
        })
      ) {
        const invoice = new InvoiceModel({
          _id: new mongoose.Types.ObjectId(),
          invoice_date: req.body.invoice_date,
          invoice_number: req.body.invoice_number,
          receipt_number: req.body.receipt_number,
          customer_name: req.body.customer_name,
          particular: req.body.particular,
          cash_in: req.body.cash_in,
          cash_out: req.body.cash_out,
          company: req.body.company_id,
          category: req.body.category_id,
          user: req.auth._id,
        });

        invoiceResult = await invoice.save();
        return {
          message: "Invoice successfully created.",
          data: invoiceResult,
          statusCode: 200,
        };
      } else {
        return { message: "Company not Exist.", data: {}, statusCode: 404 };
      }
    } catch (error) {
      throw error;
    }
  },

  Update: async (req, res) => {
    try {
      if (
        await InvoiceModel.exists({
          _id: req.params.invoice_id,
            user: mongoose.Types.ObjectId(req.auth._id),
            company: mongoose.Types.ObjectId(req.body.company_id),
        }) && await InvoiceCategoryModel.exists({_id: mongoose.Types.ObjectId(req.body.category_id),user: mongoose.Types.ObjectId(req.auth._id)})) {
        const Invoice = await InvoiceModel.updateOne(
          {
            _id: req.params.invoice_id,
            user: mongoose.Types.ObjectId(req.auth._id),
            company: mongoose.Types.ObjectId(req.body.company_id),
          },
          {
            $set: {
              invoice_date: req.body.invoice_date,
              receipt_number: req.body.receipt_number,
              customer_name: req.body.customer_name,
              particular: req.body.particular,
              cash_in: req.body.cash_in,
              cash_out: req.body.cash_out,
              category: req.body.category_id
            },
          }
        );

        return {
          message: "Invoice Updated.",
          data: Invoice,
          statusCode: 200,
        };
        
      } else {
        return {
          message: "Invoice Not Exist.",
          data: {},
          statusCode: 404,
        };
      }
    } catch (error) {
      throw error;
    }
  },

  Show: async (req, res) => {
    try {
      if (
        await InvoiceModel.exists({
          _id: mongoose.Types.ObjectId(req.params.invoice_id),
          user: mongoose.Types.ObjectId(req.auth._id),
        })
      ) {
        
        const Invoice = await InvoiceModel.findOne({
          _id: req.params.invoice_id,
          user: mongoose.Types.ObjectId(req.auth._id)
        });

        return {
          message: "Invoice Exist.",
          data: Invoice,
          statusCode: 200,
        };
        
      } else {
        
        return {
          message: "Invoice Not Exist.",
          data: {},
          statusCode: 404,
        };
      }
    } catch (error) {
      throw error;
    }
  },
  Delete: async (req, res) => {
    try {
      if (
        await InvoiceModel.exists({
          _id: req.params.invoice_id,
          user: mongoose.Types.ObjectId(req.auth._id),
          company: mongoose.Types.ObjectId(req.body.company_id),
        })
      ) {
        const Invoice = await InvoiceModel.deleteOne({
          _id: req.params.invoice_id,
          user: mongoose.Types.ObjectId(req.auth._id),
          company: mongoose.Types.ObjectId(req.body.company_id),
        });
        return {
          message: "Invoice Deleted.",
          data: Invoice,
          statusCode: 200,
        };
      } else {
        return {
          message: "Invoice Not Exist.",
          data: {},
          statusCode: 404,
        };
      }
    } catch (error) {
      throw error;
    }
  },

  Index: async (req, res) => {
    try {

      const Invoice = await InvoiceModel.find({
        user: mongoose.Types.ObjectId(req.auth._id),
        company: mongoose.Types.ObjectId(req.body.company_id),
      });
      result = {
        message: "All invoice",
        data: Invoice,
        statusCode: 200,
      };

      return result;
    } catch (error) {
      throw error;
    }
  },
};
