const mongoose = require("mongoose");
const ObjectID = require('mongodb').ObjectID;
const _ = require("lodash");
const CompanyModel = require("../Model/CompanyModel");

const isExist = async (company_name, fn) => {
  await CompanyModel.findOne(
    { company_name: company_name },
    function (err, company_name) {
      if (err) return fn(false);
      fn(company_name != null);
    }
  );
};

module.exports = {
  
  Create: async (req) => {
    const Company = new CompanyModel({
      _id: new mongoose.Types.ObjectId(),
      company_name: req.body.company_name,
    });

    try {
      //   isExist(company_name, async (response) => {
      //     if (response) {
      //       result = {
      //         message: "Company Already Exist.",
      //         data: {},
      //       };
      //     } else {
      //        companyResult = await Company.save();
      //        result = {
      //         message: "Company successfully created.",
      //         data: companyResult,
      //       };
      //     }
      //     console.log(result);
      //     return result;
      //   });

      if (await CompanyModel.findOne({ company_name: req.body.company_name })) {
        return {  message: "Company Already Exist.", data : {}, statusCode: 409};
      } else {
        companyResult = await Company.save();
        return {message: "Company successfully created.",data: companyResult, statusCode: 200};
      }

      //OR

      //   if (await CompanyModel.findOne({ company_name: company_name })) {
      //     result = {
      //       message: "Company Already Exist.",
      //       data: {},
      //     };
      //   } else {
      //     companyResult = await Company.save()
      //       .then((data) => {
      //         result = {
      //           message: "Company successfully created.",
      //           data: data,
      //         };
      //       })
      //       .catch((err) => {
      //         result = {
      //           message: "Company Already Exist.",
      //           data: {},
      //         };
      //       });
      //   }

    } catch (error) {
      throw error;
    }
  },

  Update: async (req) => {
    try {
        if (await CompanyModel.findOne({ _id: req.params.company_id })) {
          const Company = await CompanyModel.updateOne({ _id: req.params.company_id }, {$set:{company_name: req.body.company_name}});
          return {
            message: "Company Updated.",
            data: Company,
            statusCode: 200
          };
        } else {
          return {
            message: "Company Not Exist.",
            data: {},
            statusCode: 404
          };
        }
      } catch (error) {
        throw error;
      }
  },

  Show: async (req, res) => {
    try {
      if (await CompanyModel.findOne({ _id: req.params.company_id })) {
        const Company = await CompanyModel.findById(req.params.company_id);
        return {
          message: "Company Exist.",
          data: Company,
          statusCode: 201,
        };
      } else {
        return {
          message: "Company Not Exist.",
          data: {},
          statusCode: 404,
        };
      }
    } catch (error) {
      throw error;
    }
  },

  Delete: async (req, res) => {
    try {
        if (await CompanyModel.findOne({ _id: req.params.company_id })) {
          const Company = await CompanyModel.remove({ _id: req.params.company_id });
          return {
            message: "Company Deleted.",
            data: Company,
            statusCode: 200
          };
        } else {
          return {
            message: "Company Not Exist.",
            data: {},
            statusCode: 404
          };
        }
      } catch (error) {
        throw error;
      }
  },

  Index: async (req, res) => {
    try {
      const Company = await CompanyModel.find();
      result = {
        message: "All company",
        data: Company,
        statusCode:200
      };

      return result;
    } catch (error) {
      throw error;
    }
  },
};
