const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const UserModel = require("../Model/UserModel");
const jwt = require("jsonwebtoken");

module.exports = {
  Create: async (req, res) => {
    try {
      if (await UserModel.findOne({ email: req.body.email }))
        return { message: "User Already Exist.", data: {}, statusCode: 200 };

      const salt = await bcrypt.genSalt(10);
      const hashedpassword = await bcrypt.hash(req.body.password, salt);

      const User = new UserModel({
        _id: new mongoose.Types.ObjectId(),
        name: req.body.name,
        email: req.body.email,
        password: hashedpassword,
      });

      userResult = await User.save();
      return {
        message: "User successfully created.",
        data: { User: User._id },
        statusCode: 200,
      };
    } catch (error) {
      throw error;
    }
  },

  Login: async (req, res) => {
    try {
      const user = await UserModel.findOne({ email: req.body.email });
      if (!user)
        return {
          message: "Email or Password is wrong.",
          data: {},
          statusCode: 400,
        };

      const validPass = await bcrypt.compare(req.body.password, user.password);
      if (!validPass)
        return {
          message: "Email or Password is wrong.",
          data: {},
          statusCode: 400,
        };

      //https://www.npmjs.com/package/jsonwebtoken
      const token = jwt.sign({ _id: user._id }, process.env.TOKEN_SECRET);
      res.header("auth-token", token);
      return { message: "Logged In", data: { token: token }, statusCode: 200 };
    } catch (error) {
      throw error;
    }
  },
  ChangePassword: async (req, res) => {
    try {
      if (await UserModel.findOne({ _id: req.auth._id })) {
        const salt = await bcrypt.genSalt(10);
        const hashedpassword = await bcrypt.hash(req.body.new_password, salt);

        const user = await UserModel.updateOne({ _id: req.auth._id }, {$set:{password: hashedpassword}});
        return {
          message: "Password successfully changed.",
          data: { User: user._id },
          statusCode: 200,
        };
      }else{
        return {
          message: "Permission denied",
          data: {},
          statusCode: 403,
        };
      }

    } catch (error) {
      throw error;
    }
  },
};
