const mongoose = require("mongoose");
const ObjectID = require('mongodb').ObjectID;
const _ = require("lodash");
const InvoiceCategoryModel = require("../Model/InvoiceCategoryModel");

module.exports = {
  Create: async (req, res) => {
    const InvoiceCategory = new InvoiceCategoryModel({
      _id: new mongoose.Types.ObjectId(),
      category: req.body.category,
      user:req.auth._id 
    });

    try {
      
      invoiceCategoryResult = await InvoiceCategory.save();
      return {message: "Invoice Category successfully created.",data: invoiceCategoryResult, statusCode: 200};

    } catch (error) {
      throw error;
    }
  },

  Update: async (req, res) => {
    try {
        if (await InvoiceCategoryModel.exists({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) })) {
          const InvoiceCategory = await InvoiceCategoryModel.updateOne({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) }, {$set:{category: req.body.category}});
          return {
            message: "Category Updated.",
            data: InvoiceCategory,
            statusCode: 200
          };
        } else {
          return {
            message: "Category Not Exist.",
            data: {},
            statusCode: 404
          };
        }
      } catch (error) {
        throw error;
      }
  },

  Show: async (req, res) => {
    try {
      if (await InvoiceCategoryModel.exists({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) })) {
        const Company =  await InvoiceCategoryModel.findOne({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) });
        return {
          message: "Category Exist.",
          data: Company,
          statusCode: 201,
        };
      } else {
        return {
          message: "Category Not Exist.",
          data: {},
          statusCode: 404,
        };
      }
    } catch (error) {
      throw error;
    }
  },
  Delete: async (req, res) => {
    try {
        if (await InvoiceCategoryModel.findOne({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) })) {
          const Company = await InvoiceCategoryModel.deleteOne({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) });
          return {
            message: "Category Deleted.",
            data: Company,
            statusCode: 200
          };
        } else {
          return {
            message: "Category Not Exist.",
            data: {},
            statusCode: 404
          };
        }
      } catch (error) {
        throw error;
      }
  },

  Index: async (req, res) => {
    try { 
      const Category = await InvoiceCategoryModel.find({user:  mongoose.Types.ObjectId(req.auth._id)});
      result = {
        message: "All Category",
        data: Category,
        statusCode:200
      };

      return result;
    } catch (error) {
      throw error;
    }
  },
};
