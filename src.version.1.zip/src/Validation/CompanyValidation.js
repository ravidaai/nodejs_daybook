const Joi = require("@hapi/joi");
module.exports = {
  createValidation: (req) => {
    const schema = Joi.object({
      company_name: Joi.string().min(6).max(100).required(),
    });
    return schema.validate(req.body);
  },
};