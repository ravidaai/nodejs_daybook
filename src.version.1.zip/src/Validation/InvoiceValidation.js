const Joi = require("@hapi/joi");
module.exports = {
  createValidation: (req) => {
    const schema = Joi.object({
      invoice_date: Joi.date().required(),
      invoice_number: Joi.string().required(),
      receipt_number: Joi.string().required(),
      customer_name: Joi.string().min(3).max(255).required(),
      particular: Joi.string().min(3).max(255).required(),
      cash_in: Joi.required(),
      cash_out: Joi.required(),
      company_id: Joi.string().required(),
      category_id: Joi.string().required(),
    });
    return schema.validate(req.body);
  },
  updateValidation: (req) => {
    const schema = Joi.object({
      invoice_date: Joi.date().required(),
      receipt_number: Joi.string().required(),
      customer_name: Joi.string().min(3).max(255).required(),
      particular: Joi.string().min(3).max(255).required(),
      cash_in: Joi.required(),
      cash_out: Joi.required(),
      company_id: Joi.string().required(),
      category_id: Joi.string().required(),
    });
    return schema.validate(req.body);
  },
  indexValidation: (req) => {
    const schema = Joi.object({
      company_id: Joi.string().required(),
    });
    return schema.validate(req.body);
  },
};