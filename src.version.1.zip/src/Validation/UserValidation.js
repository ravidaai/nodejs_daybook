const Joi = require("@hapi/joi");
module.exports = {
  createValidation: (req) => {
    const schema = Joi.object({
      name: Joi.string().min(6).max(100).required(),
      email: Joi.string().min(6).max(50).required().email(),
      password: Joi.string().min(6).max(255).required(),
    });
    return schema.validate(req.body);
  },
  changePasswordValidation: (req) => {
    const schema = Joi.object({
      new_password: Joi.string().min(6).max(255).required(),
      confirm_password:Joi.string().min(6).max(255).required().valid(Joi.ref('new_password')),
    });
    return schema.validate(req.body);
  },
};