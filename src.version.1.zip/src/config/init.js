const mongoose = require('mongoose');
const { mongoUrl } = require('./index');
 
module.exports = {
    initializeDB: async () => {
        mongoose.connect(mongoUrl, { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex:true }, ()=>{
            console.log(`Connected to the Database. ${mongoUrl}`);
        });
       
        mongoose.Promise = global.Promise;
        //mongoose.set('useCreateIndex', true)

        // Make Mongoose use `findOneAndUpdate()`. Note that this option is `true`
        // by default, you need to set it to false.
        mongoose.set('useFindAndModify', false);
    },
 
    cors: async (req, res, next) => {
        res.header("Access-Control-Allow-Origin", "*");
        res.header(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept, Authorization"
        );
        if (req.method === "OPTIONS") {
        res.header("Access-Control-Allow-Methods", "PUT, POST, PATCH, DELETE, GET");
        return res.status(200).json({});
        }
        next();
    }
}