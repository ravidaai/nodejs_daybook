const jwt = require("jsonwebtoken");
const UserModel = require('../Model/UserModel');
module.exports = async function (req, res, next) {
  const token = req.header("auth-token");

  if (!token) return res.status(401).send("Access Denied");

  try {

    const verified = jwt.verify(token, process.env.TOKEN_SECRET);

    const user = await UserModel.findById(verified._id);

    if (!user) {
        // user no longer exists
        return res.status(401).json({ message: 'Unauthorized' });
    }
    req.auth = verified;
    next();
  } catch {
    res.send(400).send("Invalid Token");
  }
}
