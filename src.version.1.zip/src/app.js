const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const config = require('./config/init')

//routes 
const companyRoutes = require('./api/Company');
const invoiceRoutes = require('./api/Invoice');
const invoiceCategoryRoutes = require('./api/InvoiceCategory');
const authRoutes = require('./api/Auth');


//connect to DB
config.initializeDB();


//Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
//OR
//app.use(express.json());

app.use(config.cors);



//Middleware 
//run every time, add this to route if necessary
// app.use(auth)

//Home Route
app.get('/', (req, res)=>{
    res.status(200).json({
        message: 'Welcome to Petty Cash'
    });
})

//Middleware sample
// app.use('/sample', ()=>{
//     console.log('this is test');
// })

app.use('/company', companyRoutes);
app.use('/invoice', invoiceRoutes);
app.use('/category', invoiceCategoryRoutes);
app.use('/auth', authRoutes);


module.exports = app;