const mongoose = require("mongoose");
function getNextSequenceValue(model, sequenceName){
    var sequenceDocument = model.findAndModify({
       query:{invoide_id: sequenceName },
       update: {$inc:{sequence_value:100}},
       new:true
    });
    return sequenceDocument.sequence_value;
 }

 module.exports.getNextSequenceValue = getNextSequenceValue;