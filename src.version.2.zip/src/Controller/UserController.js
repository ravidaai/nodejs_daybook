const UserService = require("../Service/UserService");
const IsError = require("../Helper/IsErrorHelper");
const createError = require("http-errors");
module.exports = {
  create: async (req, res, next) => {
    try {
      const result = await UserService.Create(req, res);
        res.status(200).json(IsError(false, `User successfully created.`, result));
    } catch (error) {
      next(error);
    }
  },
  login: async (req, res, next) => {
    try {
      const access_token = await UserService.Login(req, res);
      res.status(200).json(IsError(false, `Token`, access_token));
    } catch (error) {
      next(error);
    }
  },
  changePassword: async (req, res, next) => {
    try {
      const result = await UserService.ChangePassword(req, res);
      res.status(200).json(IsError(false, `Password changed.`));
    } catch (error) {
      next(error);
    }
  },

  refresh_token: async (req, res, next) => {
    try {
      const result = await UserService.RefreshToken(req, res);
      res.status(200).json(IsError(false, `Refresh Token`, result));
    } catch (error) {
      next(error);
    }
  },

  logout: async (req, res, next) => {
    try {
      const result = await UserService.Logout(req, res, next);
      res.status(204).json(IsError(false, `Successfully Logout`,result));
    } catch (error) {
      next(error);
    }
  },
};
