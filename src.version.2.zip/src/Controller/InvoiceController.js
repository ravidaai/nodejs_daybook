const InvoiceService = require("../Service/InvoiceService");
const IsError = require("../Helper/IsErrorHelper");
module.exports = {
  delete: async (req, res) => {
    try {
      const result = await InvoiceService.Delete(req, res);
      res.status(200).json(IsError(false, `Invoice successfully deleted.`, result));
    } catch (error) {
      throw error;
    }
  },
  update: async (req, res) => {
    try {
      const result = await InvoiceService.Update(req, res);
      res.status(200).json(IsError(false, `Invoice successfully updated.`, result));
    } catch (error) {
      throw error;
    }
  },

  create: async (req, res) => {
    try {
      const result = await InvoiceService.Create(req, res);
      res.status(200).json(IsError(false, `Invoice successfully created.`, result));
    } catch (error) {
      throw error;
    }
  },
  show: async (req, res) => {
    try {
      
      const result = await InvoiceService.Show(req, res);
      res.status(200).json(IsError(false, `Invoice details.`, result));
    } catch (error) {
      throw error;
    }
  },
  index: async (req, res) => {
    try {
      const result = await InvoiceService.Index(req, res);
      res.status(200).json(IsError(false, `Invoice list.`, result));
    } catch (error) {
      throw error;
    }
  },
};
