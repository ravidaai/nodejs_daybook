const CompanyService = require("../Service/CompanyService");
const IsError = require("../Helper/IsErrorHelper");
module.exports = {
  delete: async (req, res, next) => {
    try {
      const result = await CompanyService.Delete(req, res, next);
      res.status(200).json(IsError(false, `Company successfully deleted.`, result));
    } catch (error) {
      throw error;
    }
  },
  update: async (req, res, next) => {
    try {
      const result = await CompanyService.Update(req, res, next);
      res.status(200).json(IsError(false, `Company successfully updated.`, result));
    } catch (error) {
      throw error;
    }
  },

  create: async (req, res, next) => {
    try {
      const result = await CompanyService.Create(req, res, next);
      res.status(200).json(IsError(false, `Company successfully created.`, result));
    } catch (error) {
      throw error;
    }
  },
  show: async (req, res, next) => {
    try {
      const result = await CompanyService.Show(req, res, next);
      res.status(200).json(IsError(false, `Company details`, result));
    } catch (error) {
      throw error;
    }
  },
  index: async (req, res, next) => {
    try {
      const result = await CompanyService.Index(req, res, next);
      res.status(200).json(IsError(false, `My Company`, result));
    } catch (error) {
      throw error;
    }
  },
};
