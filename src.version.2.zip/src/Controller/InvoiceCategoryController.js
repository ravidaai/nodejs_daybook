const InvoiceCategoryService = require("../Service/InvoiceCategoryService");
const IsError = require("../Helper/IsErrorHelper");
module.exports = {
  delete: async (req, res) => {
    try {
      const result = await InvoiceCategoryService.Delete(req, res);
      res.status(200).json(IsError(false, `Category successfully deleted.`, result));
    } catch (error) {
      throw error;
    }
  },
  update: async (req, res) => {
    try {
      const result = await InvoiceCategoryService.Update(req, res);
      res.status(200).json(IsError(false, `Category successfully updated.`, result));
    } catch (error) {
      throw error;
    }
  },

  create: async (req, res) => {
    try {
      const result = await InvoiceCategoryService.Create(req, res);
        res.status(200).json(IsError(false, `Category successfully created.`, result));
    } catch (error) {
      throw error;
    }
  },
  show: async (req, res) => {
    try {
      const result = await InvoiceCategoryService.Show(req, res);
      res.status(200).json(IsError(false, `Category details.`, result));
    } catch (error) {
      throw error;
    }
  },
  index: async (req, res) => {
    try {
      const result = await InvoiceCategoryService.Index(req, res);
      res.status(200).json(IsError(false, `category list.`, result));
    } catch (error) {
      throw error;
    }
  },
};
