const express = require('express');
const router = express.Router();
const invoiceController = require('../Controller/InvoiceController');
const verifyToken = require('../Middleware/verifyToken');
const Request = require('../Middleware/Request/InvoiceRequest');
/**
 * GET request to /invoice
 */
router.get('/', [verifyToken, Request.index],  async (req, res, next) => {
    await invoiceController.index(req, res)
});

/**
 * GET request to /invoice/:id
 */
router.get('/:invoice_id', [verifyToken, Request.show], async(req, res, next) => {
    await invoiceController.show(req, res);
});

/**
 * POST request to /invoice
 */
router.post("/", [verifyToken, Request.create], async (req, res, next) => {
    await invoiceController.create(req, res)
});

/**
 * Delete request to /invoice/:id
 */
 router.delete('/:invoice_id', [verifyToken, Request.delete], async(req, res, next) => {
   await invoiceController.delete(req, res);

});

/**
 * Update request to /invoice/:id
 */
 router.patch('/:invoice_id', [verifyToken, Request.update], async(req, res, next) => {
    await invoiceController.update(req, res);
});
  

module.exports = router;