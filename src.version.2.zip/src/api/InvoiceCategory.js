const express = require('express');
const router = express.Router();
const InvoiceCategoryController = require('../Controller/InvoiceCategoryController');
const verifyToken = require('../Middleware/verifyToken');
const Request = require('../Middleware/Request/InvoiceCategoryRequest');
/**
 * GET request to /category
 */
router.get('/', [verifyToken, Request.index],  async (req, res, next) => {
    await InvoiceCategoryController.index(req, res)
});

/**
 * GET request to /category/:id
 */
router.get('/:category_id', [verifyToken, Request.show], async(req, res, next) => {
    await InvoiceCategoryController.show(req, res);
});

/**
 * POST request to /category
 */
router.post("/", [verifyToken, Request.create], async (req, res, next) => {
    await InvoiceCategoryController.create(req, res)
});

/**
 * Delete request to /category/:id
 */
 router.delete('/:category_id', [verifyToken, Request.delete], async(req, res, next) => {
   await InvoiceCategoryController.delete(req, res);

});

/**
 * Update request to /category/:id
 */
 router.patch('/:category_id', [verifyToken, Request.update], async(req, res, next) => {
    await InvoiceCategoryController.update(req, res);
});
  

module.exports = router;