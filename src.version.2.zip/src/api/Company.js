const express = require('express');
const router = express.Router();
const companyController = require('../Controller/CompanyController');
const verifyToken = require('../Middleware/verifyToken');
const {verifyAccessToken} = require('../Helper/jwtHelper');
const Request = require('../Middleware/Request/CompanyRequest');
/**
 * GET request to /company
 */
router.get('/', [verifyAccessToken, Request.index],  async (req, res, next) => {
    await companyController.index(req, res, next)
});

/**
 * GET request to /company/:id
 */
router.get('/:company_id', [verifyToken, Request.show], async(req, res, next) => {
    await companyController.show(req, res, next);
});

/**
 * POST request to /company
 */
router.post("/", [verifyToken, Request.create], async (req, res, next) => {
    await companyController.create(req, res, next)
});

/**
 * Delete request to /company/:id
 */
 router.delete('/:company_id', [verifyToken, Request.delete], async(req, res, next) => {
   await companyController.delete(req, res, next);

});

/**
 * Update request to /company/:id
 */
 router.patch('/:company_id', [verifyToken, Request.update], async(req, res, next) => {
    await companyController.update(req, res, next);
});
  

module.exports = router;