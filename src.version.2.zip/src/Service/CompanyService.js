const mongoose = require("mongoose");
const ObjectID = require('mongodb').ObjectID;
const _ = require("lodash");
const CompanyModel = require("../Model/CompanyModel");



module.exports = {
  
  Create: async (req, res, next) => {
    try {
      const Company = new CompanyModel({
        _id: new mongoose.Types.ObjectId(),
        company_name: req.body.company_name,
        user:req.auth._id 
      });
      companyResult = await Company.save();
      return companyResult;
    } catch (error) {
      throw error;
    }
  },

  Update: async (req, res, next) => {
    try {
      const Company = await CompanyModel.updateOne({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) }, {$set:{company_name: req.body.company_name}});
      return Company;
      } catch (error) {
        throw error;
      }
  },

  Show: async (req, res, next) => {
    try {
      const Company =  await CompanyModel.findOne({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) });
      return Company;
    } catch (error) {
      throw error;
    }
  },
  Delete: async (req, res, next) => {
    try {
      const Company = await CompanyModel.deleteOne({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) });
      return Company;  
    } catch (error) {
        throw error;
      }
  },

  Index: async (req, res, next) => {
    try { 
      const Company = await CompanyModel.find({user:  mongoose.Types.ObjectId(req.payload.auth_id)});
      return Company;
    } catch (error) {
      throw error;
    }
  },
};
