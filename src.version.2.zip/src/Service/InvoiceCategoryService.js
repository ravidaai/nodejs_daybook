const mongoose = require("mongoose");
const ObjectID = require('mongodb').ObjectID;
const _ = require("lodash");
const InvoiceCategoryModel = require("../Model/InvoiceCategoryModel");

module.exports = {
  Create: async (req, res) => {
    

    try {
      const InvoiceCategory = new InvoiceCategoryModel({
        _id: new mongoose.Types.ObjectId(),
        category: req.body.category,
        user:req.auth._id 
      });

      result = await InvoiceCategory.save();
      return result;

    } catch (error) {
      throw error;
    }
  },

  Update: async (req, res) => {
    try {
      const result = await InvoiceCategoryModel.updateOne({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) }, {$set:{category: req.body.category}});
      return result;
      } catch (error) {
        throw error;
      }
  },

  Show: async (req, res) => {
    try {
      const result =  await InvoiceCategoryModel.findOne({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) });
      return result;
    } catch (error) {
      throw error;
    }
  },
  Delete: async (req, res) => {
    try {
      const result = await InvoiceCategoryModel.deleteOne({ _id: req.params.category_id, user:  mongoose.Types.ObjectId(req.auth._id) });
      return result;
      } catch (error) {
        throw error;
      }
  },

  Index: async (req, res) => {
    try { 
      const result = await InvoiceCategoryModel.find({user:  mongoose.Types.ObjectId(req.auth._id)});
      return result;
    } catch (error) {
      throw error;
    }
  },
};
