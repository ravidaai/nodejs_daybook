const Joi = require("@hapi/joi");
const IsError = require("../../Helper/IsErrorHelper");
const mongoose = require("mongoose");
const InvoiceCategoryModel = require("../../Model/InvoiceCategoryModel");
module.exports = {
  create: async (req, res, next) => {
    const schema = Joi.object({
      category: Joi.string().min(6).max(100).required(),
    });

    const payload = {
      category: req.body.category,
    };

    const { error } = schema.validate(payload);
    if (error) {
      return res
        .status(406)
        .json(IsError(error, `Error in User Data : ${error.message}`));
    }
    next();
  },
  update: async (req, res, next) => {
    const schema = Joi.object({
      category: Joi.string().min(6).max(100).required(),
    });

    const payload = {
      category: req.body.category,
    };

    const { error } = schema.validate(payload);
    if (error) {
      return res
        .status(406)
        .json(IsError(error, `Error in User Data : ${error.message}`));
    }

    //if not exist
    if (
      !(await InvoiceCategoryModel.exists({
        _id: req.params.category_id,
        user: mongoose.Types.ObjectId(req.auth._id),
      }))
    ) {
      return res.status(406).json(IsError(true, `Category Not Exist.`));
    }

    next();
  },
  delete: async (req, res, next) => {
    //if not exist
    if (
      !(await InvoiceCategoryModel.exists({
        _id: req.params.category_id,
        user: mongoose.Types.ObjectId(req.auth._id),
      }))
    ) {
      return res.status(406).json(IsError(true, `Category Not Exist.`));
    }
    next();
  },
  show: async (req, res, next) => {
    //if not exist
    if (
      !(await InvoiceCategoryModel.exists({
        _id: req.params.category_id,
        user: mongoose.Types.ObjectId(req.auth._id),
      }))
    ) {
      return res.status(406).json(IsError(true, `Category Not Exist.`));
    }

    next();
  },
  index: async (req, res, next) => {
    next();
  },
};
