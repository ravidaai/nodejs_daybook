const Joi = require("@hapi/joi");
const IsError = require("../../Helper/IsErrorHelper");
const CompanyModel = require("../../Model/CompanyModel");
const mongoose = require("mongoose");

module.exports = {
  create: async (req, res, next) => {
    const schema = Joi.object({
      company_name: Joi.string().min(6).max(100).required(),
    });

    const payload = {
      company_name: req.body.company_name,
    };

    const { error } = schema.validate(payload);
    if (error) {
      return res
        .status(406)
        .json(IsError(error, `Error in User Data : ${error.message}`));
    }

    // check if already exist
    if (await CompanyModel.exists({ company_name: req.body.company_name })) {
      return res.status(406).json(IsError(true, `Company Already Exist.`));
    }

    next();

  },
  update: async (req, res, next) => {
    const schema = Joi.object({
      company_name: Joi.string().min(6).max(100).required(),
    });

    const payload = {
      company_name: req.body.company_name,
    };

    const { error } = schema.validate(payload);
    if (error) {
      return res
        .status(406)
        .json(IsError(error, `Error in User Data : ${error.message}`));
    }

    //if not exist
    if (!await CompanyModel.exists({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) })) {
      return res.status(406).json(IsError(true, `Company Not Exist.`));
    }

    next();
  },

  delete: async (req, res, next) => {
    if (!await CompanyModel.findOne({ _id: req.params.company_id, user:  mongoose.Types.ObjectId(req.auth._id) })) {
      return res.status(406).json(IsError(true, `Company Not Exist.`));
    }

    next();
  },

  show: async (req, res, next) => {
    const isExist = await CompanyModel.exists({
      _id: req.params.company_id,
      user: mongoose.Types.ObjectId(req.auth._id),
    });
    if (!isExist) {
      return res.status(404).json(IsError(true, `Company Not Exist.`));
    }

    next();
  },

  index: async (req, res, next) => {
    
    await next();
  },
};

// const validation = joi.object({
//   userName: joi.string().alphanum().min(3).max(25).trim(true).required(),
//   email: joi.string().email().trim(true).required(),
//   password: joi.string().min(8).trim(true).required(),
//   mobileNumber: joi.string().length(10).pattern(/[6-9]{1}[0-9]{9}/).required(),
//   birthYear: joi.number().integer().min(1920).max(2000),
//   skillSet: joi.array().items(joi.string().alphanum().trim(true))
// .default([]),
//  is_active: joi.boolean().default(true),
// });
