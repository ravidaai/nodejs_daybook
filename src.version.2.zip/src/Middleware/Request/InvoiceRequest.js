const Joi = require("@hapi/joi");
const mongoose = require("mongoose");
const IsError = require("../../Helper/IsErrorHelper");
const InvoiceModel = require("../../Model/InvoiceModel");
const CompanyModel = require("../../Model/CompanyModel");
const InvoiceCategoryModel = require("../../Model/InvoiceCategoryModel");

module.exports = {
  create: async (req, res, next) => {
    const schema = Joi.object({
      invoice_date: Joi.date().required(),
      invoice_number: Joi.string().required(),
      receipt_number: Joi.string().required(),
      customer_name: Joi.string().min(3).max(255).required(),
      particular: Joi.string().min(3).max(255).required(),
      cash_in: Joi.required(),
      cash_out: Joi.required(),
      company_id: Joi.string().required(),
      category_id: Joi.string().required(),
    });

    const payload = {
      invoice_date: req.body.invoice_date,
      invoice_number: req.body.invoice_number,
      receipt_number: req.body.receipt_number,
      customer_name: req.body.customer_name,
      particular: req.body.particular,
      cash_in: req.body.cash_in,
      cash_out: req.body.cash_out,
      company_id: req.body.company_id,
      category_id: req.body.category_id,

    };

    const { error } = schema.validate(payload);
    if (error) {
      return res
        .status(406)
        .json(IsError(error, `Error in User Data : ${error.message}`));
    }

    // check if already exist
    if (!await CompanyModel.exists({
        user: mongoose.Types.ObjectId(req.auth._id),
        _id: mongoose.Types.ObjectId(req.body.company_id),
    }) || !await InvoiceCategoryModel.exists({_id: mongoose.Types.ObjectId(req.body.category_id),user: mongoose.Types.ObjectId(req.auth._id)})) {
      return res.status(406).json(IsError(true, `Company/Category not exist.`));
    }

    next();
  },
  update: async (req, res, next) => {
    const schema = Joi.object({
      invoice_date: Joi.date().required(),
      receipt_number: Joi.string().required(),
      customer_name: Joi.string().min(3).max(255).required(),
      particular: Joi.string().min(3).max(255).required(),
      cash_in: Joi.required(),
      cash_out: Joi.required(),
      company_id: Joi.string().required(),
      category_id: Joi.string().required(),
    });

    const payload = {
      invoice_date: req.body.invoice_date,
      invoice_number: req.body.invoice_number,
      receipt_number: req.body.receipt_number,
      customer_name: req.body.customer_name,
      particular: req.body.particular,
      cash_in: req.body.cash_in,
      cash_out: req.body.cash_out,
      company_id: req.body.company_id,
      category_id: req.body.category_id,

    };

    const { error } = schema.validate(payload);
    if (error) {
      return res
        .status(406)
        .json(IsError(error, `Error in User Data : ${error.message}`));
    }

    // check if already exist
    if (!await InvoiceModel.exists({
      _id: req.params.invoice_id,
        user: mongoose.Types.ObjectId(req.auth._id),
        company: mongoose.Types.ObjectId(req.body.company_id),
    }) || !await InvoiceCategoryModel.exists({_id: mongoose.Types.ObjectId(req.body.category_id),user: mongoose.Types.ObjectId(req.auth._id)})) {
      return res.status(406).json(IsError(true, `Company/Category not exist.`));
    }

    next();
  },
  delete: async (req, res, next) => {
    if (!await InvoiceModel.exists({
      _id: req.params.invoice_id,
      user: mongoose.Types.ObjectId(req.auth._id),
      company: mongoose.Types.ObjectId(req.body.company_id),
    })) {
      return res.status(406).json(IsError(true, `Invoice not exist.`));
    }
    next();
  },
  show: async (req, res, next) => {
    if (!await InvoiceModel.exists({
      _id: mongoose.Types.ObjectId(req.params.invoice_id),
      user: mongoose.Types.ObjectId(req.auth._id),
    })) {
      return res.status(406).json(IsError(true, `Invoice not exist.`));
    }

    next();
  },
  index: async (req, res, next) => {
    const schema = Joi.object({
      company_id: Joi.string().required(),
    });

    const payload = {
      company_id: req.body.company_id,
    };

    const { error } = schema.validate(payload);
    if (error) {
      return res
        .status(406)
        .json(IsError(true, `${error.message}`));
    }

    if (!await InvoiceModel.exists({
      user: mongoose.Types.ObjectId(req.auth._id),
      company: mongoose.Types.ObjectId(req.body.company_id),
    })) {
      return res.status(406).json(IsError(true, `Invoice list not exist.`));
    }

    
    next();
  },
};
